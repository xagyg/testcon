package roast;

public interface Domain {

public int size();

public Object elementAt(int i);

public String toString();

}
