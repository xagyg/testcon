package roast;

import java.util.*;

// wrapper for Vector so it can serve as a Domain
public class VectorDomain extends Vector implements Domain { }
