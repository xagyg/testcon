package roast;

import java.util.*;

public interface Factory {

public Iterator create(Vector v);

}
