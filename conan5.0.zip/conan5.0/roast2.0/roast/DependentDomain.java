package roast;

import java.util.*;

public interface DependentDomain extends Domain {

public void setDomain(Vector tuple);

}
