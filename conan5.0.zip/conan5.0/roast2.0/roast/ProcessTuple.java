package roast;

import java.util.*;

public interface ProcessTuple {

public void processTuple(Vector tuple);

}
