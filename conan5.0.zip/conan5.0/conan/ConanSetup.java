package conan;

public class ConanSetup {

    public void setup() {}
    public void teardown() {}
}