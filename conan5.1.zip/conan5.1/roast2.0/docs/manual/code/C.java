public class C {
	public static void main(String[] argv)
	{ System.out.println("hello"); }
}
